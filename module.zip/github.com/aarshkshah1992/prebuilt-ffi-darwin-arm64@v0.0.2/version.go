package ffi

// Version is most similar to semver's minor version.
// It is here as we cannot use gomod versioning due to local replace directives
// for native dependencies.
const Version int = 3
