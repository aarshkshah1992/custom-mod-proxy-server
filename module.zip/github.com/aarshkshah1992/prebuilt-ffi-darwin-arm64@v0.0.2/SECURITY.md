# Security Policy

## Reporting a Vulnerability

For reporting *critical* and *security* bugs, please consult our [Security Policy and Responsible Disclosure Program information](https://github.com/filecoin-project/community/blob/master/SECURITY.md)

## Reporting a non security bug

For non-critical bugs, please simply file a GitHub issue on this repo.
