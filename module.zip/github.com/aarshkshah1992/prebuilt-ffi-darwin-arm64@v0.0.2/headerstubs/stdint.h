typedef unsigned char uint8_t;
typedef long long int32_t;
typedef unsigned long long uint32_t;
typedef long long int64_t;
typedef unsigned long long uint64_t;
typedef unsigned long long uintptr_t; /* only valid on 64bit systems */

